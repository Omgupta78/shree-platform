# Shree Classified — classified advertising platform

Digital classifieds for **Shree Advertising & Marketing**, Roorkee.

Next.js 16 (App Router) · React 19 · TypeScript (strict) · Tailwind CSS v4 · Supabase (Postgres, Auth, Storage) · deployed on Vercel.

---

## Build status

**Phases 1 to 7 are complete.** The site reads and writes real data, and the
office has somewhere to work: accounts, submission, storage, the public read
path, and an admin area with a full moderation workflow behind it.

| Phase | Scope | Status |
| ----- | ----- | ------ |
| 1 | Foundation — schema, RLS, design system, shell | **Done** |
| 2 | Home page | **Done** |
| 3 | Browse & search — categories, filters, sorting, pagination, SEO | **Done** |
| 4 | The advertisement page — gallery, contact, similar, structured data | **Done** |
| 5 | The submission form — eight steps, zod validation, drafts, preview | **Done** |
| 6 | The backend — accounts, submission, storage, payments and reports schema, audit trail | **Done** |
| 7 | The office — admin area, moderation workflow, reports, categories, activity log | **Done** |
| 8 | Payments integration, renewals, notifications, analytics | Not started |

### Routes

| Route | What it is |
| ----- | ---------- |
| `/` | Home |
| `/categories` | Category index |
| `/classifieds` | All advertisements, filtered and sorted from the URL |
| `/classifieds/[slug]` | A category page, or one advertisement |
| `/post-ad` | The submission form |
| `/sign-in`, `/sign-up`, `/forgot-password`, `/update-password` | Accounts |
| `/my-ads` | An advertiser's own advertisements |
| `/auth/callback`, `/auth/sign-out` | Session handling |
| `/search`, `/robots.txt`, `/sitemap.xml` | Search redirect and crawler files |
| `/admin` | Dashboard — what is waiting, what has arrived |
| `/admin/advertisements` | Every advertisement, with search and filters |
| `/admin/advertisements/pending` | The review queue, with bulk actions |
| `/admin/advertisements/changes-requested`, `/approved`, `/rejected`, `/expired` | The other queues |
| `/admin/advertisements/[id]` | One advertisement, and the decisions available on it |
| `/admin/reports` | Reader reports |
| `/admin/activity` | The moderation history |
| `/admin/categories`, `/admin/users` | Administrators only |

### Not built yet, by instruction

The payment provider integration, renewals, notifications and analytics. The
schema for payments is in place and tested — what is missing is the provider,
not the record it would settle against.

One thing Phase 7 leaves unfinished on purpose: an advertiser can *see* that a
change has been asked for, but cannot yet edit and resubmit from their own
page. The database supports the whole round trip — `changes_requested →
pending` is a permitted move for the owner, and is tested — but the editing
form itself is not built.

---

## Getting started

### 1. Create the Supabase project

1. Create a project at [supabase.com](https://supabase.com). Choose the Mumbai (`ap-south-1`) region for the lowest latency to Roorkee.
2. Open **SQL Editor** and run each file in `supabase/migrations/` **in filename order**:
   - `0001_core_schema.sql` — tables, constraints, triggers, row-level security
   - `0002_seed_reference_data.sql` — categories, locations, site settings
   - `0003_browse_views.sql` — aggregate views for browse pages
   - `0004_advertisement_kinds_and_packages.sql` — display advertisements, packages, artwork, database-issued slugs
   - `0005_payments_reports_favourites.sql` — payments, reader reports, saved advertisements
   - `0006_storage_and_audit_trail.sql` — storage buckets and policies, the append-only audit trail
   - `0007_moderation_guard_and_public_views.sql` — the hardened moderation guard, view counting, and the three read views
   - `0008_ad_status_changes_requested.sql` — one statement, on its own: see the note inside it
   - `0009_moderation_workflow.sql` — the transition table, the moderation call, the admin views and the dashboard counts
3. Storage buckets are created by migration `0006`, so there is nothing to do by
   hand: `ad-images` (public) and `ad-artwork` (private). If your project predates
   that migration, check under **Storage** that both exist.

### 2. Configure the app

```bash
cp .env.example .env.local
```

Fill in from **Project Settings → API** in Supabase:

| Variable | Where it is used | Secret? |
| -------- | ---------------- | ------- |
| `NEXT_PUBLIC_SUPABASE_URL` | Browser and server | No |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Browser and server | No — row-level security governs access |
| `SUPABASE_SERVICE_ROLE_KEY` | Server only. Bypasses all security | **Yes** |
| `NEXT_PUBLIC_SITE_URL` | Canonical URLs, sitemap, share links | No |

`SUPABASE_SERVICE_ROLE_KEY` must never be given a `NEXT_PUBLIC_` prefix. The module
that reads it imports `server-only`, so importing it from client code is a build error.

### 3. Run it

```bash
npm install
npm run dev          # http://localhost:3000
```

Without Supabase credentials the site still builds and runs — it shows an explicit
"database not connected" notice rather than inventing placeholder listings.

### 4. Make yourself an administrator

Sign up at `/sign-up`, then in the Supabase **SQL Editor**:

```sql
update public.profiles set role = 'admin' where email = 'you@example.com';
```

The SQL Editor connects without a JWT, which the schema treats as a trusted
connection — this is the only way the first administrator can be created, since
promoting a user normally requires an existing administrator.

---

## Commands

| Command | Purpose |
| ------- | ------- |
| `npm run dev` | Development server |
| `npm run build` | Production build |
| `npm run start` | Serve the production build |
| `npm run typecheck` | `tsc --noEmit` |
| `npm run lint` | ESLint |
| `npm run db:test` | Apply the migrations to a scratch Postgres and assert the security policies |
| `npm run e2e` | Playwright, against a production build on port 3400 |
| `npm run verify` | Typecheck, lint, build and end-to-end, in that order |

`db:test` needs a local Postgres 16 and `psql`; it never touches Supabase. It
applies every migration to a scratch database and runs **170 assertions**: 22 in
`rls_checks.sql` from Phase 1, 103 in `backend_checks.sql` covering the ten
escalation attacks, consent, payments, reports, favourites, the audit trail,
storage paths, slug issuance and reference format, and 45 in
`moderation_checks.sql` covering the transition table, the moderation call, the
audit note, what each role may read, and what the public can see at every step.

`e2e` needs a browser once: `npx playwright install chromium`.

---

## Deploying to Vercel

1. Push this repository to GitHub.
2. In Vercel: **Add New → Project → import the repository**.
3. Add the four environment variables above under **Settings → Environment Variables**.
   Leave `NEXT_PUBLIC_SITE_URL` blank to derive it from the deployment URL, or set it
   to your custom domain once connected.
4. Deploy, then add your domain under **Settings → Domains** and follow the DNS
   instructions at your registrar.

Vercel's free Hobby plan is intended for non-commercial use — a business site
normally needs the Pro plan. Please confirm current terms on Vercel's pricing page.

---

## Architecture

### Authorisation lives in the database

Every table has row-level security enabled. The application always connects with
the anon key, never the service role, so a bug in a page cannot expose an
unapproved advertisement or another user's data. `supabase/test/rls_checks.sql`
and `supabase/test/backend_checks.sql` assert these guarantees.

Database-enforced rules include: an advertiser cannot approve their own
advertisement, cannot grant themselves featured placement, cannot promote
themselves to administrator, cannot extend their own advertisement's expiry or
rewrite its view count, cannot change its package or the price stamped on it, and
cannot choose its URL or its reference; editing a live advertisement returns it to
the review queue; a rejected advertisement must carry a reason.

### The server never trusts the client

`user_id` comes from a verified token. `status` is always `pending` on submission,
and a trigger refuses anything else. `slug` and `reference` are issued by the
database — and migration 0007 revokes the privilege to insert them at all, so a
statement naming one is refused before a row is built. The price is read from the
package record by a trigger. Submission re-validates with the same zod schema the
browser used, so the two cannot disagree about what a valid advertisement is.

### The public read path honours consent in SQL

Public pages read `public_ads`, a view that applies "approved and not expired" in
SQL and returns NULL for a telephone number the advertiser chose not to publish.
Contact email is not in the view at all. The contact columns are revoked from
`anon` and `authenticated` at the table, so the interface is never handed a number
it would have to remember to hide. Two companion views say the rest in SQL:
`owner_ads` (your own, any state) and `moderation_ads` (everything, staff only).

### Storage ownership is the path

Every object is stored at `<user id>/<advertisement id>/<file>`, and the storage
policies compare the first segment against `auth.uid()`. Uploads are sniffed for
their actual content before they are stored, and the extension comes from that
rather than from the file name the client sent — `ad-images` is a public bucket,
and a file served from the site's own origin under a name the client chose is how
an "image" upload becomes stored HTML. Display artwork goes to a separate private
bucket: it is commercially sensitive before publication, and frequently a PDF.

### Moderation is a transition table, not a status column

Which states an advertisement may move between is written down once, in
`is_permitted_ad_transition()`, and enforced by a trigger for everybody the
guard applies to — staff included. `rejected → approved` is absent, so a
refusal cannot be quietly undone in one step; the way back is through the
queue. `expired → approved` is absent, because bringing a finished
advertisement back is a renewal, and renewals are paid for.

A decision is one call: `moderate_advertisement(id, action, note)`. It re-checks
the role, re-checks the transition, refuses a rejection with no reason, and
writes the audit entry in the same transaction as the change. That is not
tidiness — PostgREST gives every request its own transaction, so a decision sent
as one call and its explanation sent as another can come apart, leaving either
a status change nobody can account for or a note about a change that never
happened.

### The office and the public read different views

`moderation_ads` carries the advertiser's email address and telephone number
and returns nothing unless `is_staff()`. `public_ads` nulls a withheld number
and has no contact email at any consent level. The admin review page
deliberately does not reuse the public advertisement component: sharing one
would mean either that the office cannot see what it needs, or that somebody
widens the public component "just for admin" and the widening ships to the
reading side.

### Three independent checks guard the admin area

`src/proxy.ts` reads the caller's role and issues a real HTTP redirect before
any page renders. The admin layout asks again, for the day a route is added and
the proxy's matcher is not. And the database refuses regardless — the admin
views return nothing and every moderation call raises. The third is the one
that matters; the first two are a better experience. Being on `/admin` has never
made anybody staff.

### The audit trail is append-only

`audit_log` records every status change, role grant, block, payment settlement and
report resolution, with the actor read from the verified token. UPDATE and DELETE
are revoked and a trigger raises on either, because an audit trail somebody can
quietly edit is decoration.

### Contact details sit on the advertisement, not the profile

`profiles` is readable only by its owner and staff. Contact name, phone, WhatsApp
and email are columns on `ads`. A phone number therefore cannot leak through the
profiles table, and an advertiser can use different numbers on different ads.

### Category-specific fields use JSONB

Property ads need bedrooms and area; vehicles need year and kilometres. These live
in `ads.attributes` (JSONB, GIN-indexed) so adding a category never needs a
migration.

### Business values live in `app_settings`

Advertisement duration, image limits, the office address, phone numbers and
WhatsApp number are database rows, not constants. Changing the office phone number
is an UPDATE, not a deployment. The footer and header read from this table.

### Full-text search uses the `simple` dictionary

Advertisement copy is frequently Hindi. The `english` dictionary would stem Hindi
words incorrectly, so the generated `search_vector` column uses `simple`, which
indexes both scripts. Titles are weighted above descriptions.

### Design tokens, two layers

`@theme` holds the raw palette; `@theme inline` maps semantic names (`surface`,
`fg-muted`, `primary-solid`, `critical-surface`) onto CSS variables. Components
reference only semantic tokens, so light and dark mode is a variable swap rather
than a `dark:` variant on every element. Dark mode follows the system setting and
can be overridden with `data-theme` on `<html>` when a toggle is added.

All text colour pairs were checked against WCAG AA (4.5:1) in both themes.

### Fonts are self-hosted

IBM Plex Sans, IBM Plex Sans Devanagari and Source Serif 4 ship as woff2 files in
`src/assets/fonts` and load through `next/font/local`. No third-party request on
first paint, and the Devanagari face means Hindi advertisement copy renders
properly rather than falling back to a system font.

---

## Project layout

```
src/
  app/
    (auth)/                sign in, sign up, password reset, and their actions
    auth/                  callback and sign-out route handlers
    classifieds/           browse, one advertisement, report and view actions
    my-ads/                an advertiser's own list
    post-ad/               the submission form and its server action
  components/
    advertisements/        card, gallery, contact, report modal, view counter
    auth/                  account forms, header actions, sign-in panel
    classifieds/           filters, sorting, pagination, results
    layout/                header, footer, mobile nav
    post-ad/               the eight-step form
    ui/                    button, badge, container, field, icons, states
  lib/
    auth/                  session reading and the account schemas
    classifieds/           query parsing, filters, similarity — pure functions
    data/                  data access — public_ads, owner_ads, taxonomy, settings
    post-ad/               schema, state, drafts, file rules, content sniffing
    supabase/              browser, server, anonymous and service-role clients
    env.ts                 zod-validated environment access
  types/                   content and database types
supabase/
  migrations/              numbered, run in order
  test/                    local validation harness (never applied to Supabase)
e2e/                       Playwright, against a production build
```

## Regenerating database types

Once the project is linked, replace the hand-written types:

```bash
npx supabase gen types typescript --project-id <id> --schema public > src/types/database.ts
```

## A note on advertiser liability

The footer carries the same disclaimer as the printed edition: advertisers are
responsible for their own content and readers should verify claims independently.
Keep it — it is there for a reason.
