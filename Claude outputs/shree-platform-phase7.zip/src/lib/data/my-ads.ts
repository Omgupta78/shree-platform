import 'server-only';

import { cache } from 'react';

import { publicImageUrl } from '@/lib/storage';
import { createSupabaseServerClient } from '@/lib/supabase/server';
import type { AdStatus, OwnerAdRow } from '@/types/database';

/**
 * An advertiser's own advertisements.
 *
 * Read from `owner_ads`, which filters on `user_id = auth.uid()` inside the
 * database. There is no user id in this file and nothing to pass one to: a bug
 * here cannot fetch somebody else's advertisements, because the query has no
 * way to name them.
 */

export interface MyAdvertisement {
  id: string;
  reference: string;
  slug: string;
  kind: 'classified' | 'display';
  title: string;
  status: AdStatus;
  rejectionReason: string | null;
  isFeatured: boolean;
  publishedAt: string | null;
  expiresAt: string | null;
  createdAt: string;
  viewCount: number;
  categorySlug: string | null;
  locationSlug: string | null;
  coverImageUrl: string | null;
  packageId: string | null;
}

const COLUMNS = `
  id, reference, slug, kind, title, status, rejection_reason, is_featured,
  published_at, expires_at, created_at, view_count, category_slug, location_slug,
  package_id
` as const;

type Row = Pick<
  OwnerAdRow,
  | 'id'
  | 'reference'
  | 'slug'
  | 'kind'
  | 'title'
  | 'status'
  | 'rejection_reason'
  | 'is_featured'
  | 'published_at'
  | 'expires_at'
  | 'created_at'
  | 'view_count'
  | 'category_slug'
  | 'location_slug'
  | 'package_id'
>;

export const getMyAdvertisements = cache(async (): Promise<MyAdvertisement[]> => {
  const supabase = await createSupabaseServerClient();

  const { data, error } = await supabase
    .from('owner_ads')
    .select(COLUMNS)
    .order('created_at', { ascending: false });

  if (error || !data) return [];
  const rows = data as unknown as Row[];
  if (!rows.length) return [];

  // Cover images in one query rather than one per advertisement.
  const { data: images } = await supabase
    .from('ad_images')
    .select('ad_id, storage_path, sort_order')
    .in(
      'ad_id',
      rows.map((row) => row.id),
    )
    .order('sort_order', { ascending: true });

  const coverByAd = new Map<string, string>();
  for (const image of images ?? []) {
    if (!coverByAd.has(image.ad_id)) coverByAd.set(image.ad_id, image.storage_path);
  }

  return rows.map((row) => ({
    id: row.id,
    reference: row.reference,
    slug: row.slug,
    kind: row.kind,
    title: row.title,
    status: row.status,
    rejectionReason: row.rejection_reason,
    isFeatured: row.is_featured,
    publishedAt: row.published_at,
    expiresAt: row.expires_at,
    createdAt: row.created_at,
    viewCount: row.view_count,
    categorySlug: row.category_slug,
    locationSlug: row.location_slug,
    coverImageUrl: publicImageUrl(coverByAd.get(row.id)),
    packageId: row.package_id,
  }));
});

/**
 * What each state means, in the advertiser's terms.
 *
 * "Pending" is a database word. Somebody who has just sent an advertisement
 * wants to know whether anything is expected of them, and the answer is no.
 */
export const STATUS_COPY: Record<
  AdStatus,
  { label: string; tone: 'neutral' | 'success' | 'warning' | 'danger'; note: string }
> = {
  draft: {
    label: 'Draft',
    tone: 'neutral',
    note: 'Not sent to us yet.',
  },
  pending: {
    label: 'With our office',
    tone: 'warning',
    note: 'We are reading it. Nothing is needed from you.',
  },
  approved: {
    label: 'Live',
    tone: 'success',
    note: 'Published and visible to readers.',
  },
  rejected: {
    label: 'Not published',
    tone: 'danger',
    note: 'We could not publish it as written.',
  },
  changes_requested: {
    label: 'Needs a change',
    tone: 'warning',
    note: 'Our office has asked for one thing to be corrected before it can run.',
  },
  expired: {
    label: 'Finished',
    tone: 'neutral',
    note: 'Its run has ended. Our office can start it again.',
  },
  sold: {
    label: 'Marked sold',
    tone: 'neutral',
    note: 'You told us this one is done.',
  },
};
