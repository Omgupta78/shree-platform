'use server';

import { revalidatePath } from 'next/cache';
import { z } from 'zod';

import { NotStaffError, requireAdministrator, requireStaff } from '@/lib/admin/guard';
import {
  bulkModerationInputSchema,
  moderationInputSchema,
} from '@/lib/admin/moderation';
import { isSupabaseConfigured } from '@/lib/env';
import { createSupabaseServerClient } from '@/lib/supabase/server';

/**
 * Every write the office can make.
 *
 * None of these is an UPDATE against a table. Each one calls a database
 * function that re-checks the role, re-checks that the move is permitted, and
 * writes the audit entry in the same transaction as the change itself. That
 * matters for a specific reason: PostgREST gives each request its own
 * transaction, so a decision sent as one call and its explanation sent as
 * another can come apart — leaving either a status change nobody can account
 * for, or a note about a change that never happened.
 *
 * The checks in this file are therefore for the interface's benefit, not the
 * database's. A malicious client calling these actions directly still has to
 * get past `is_staff()` inside Postgres, and posting `action: "approve"` at an
 * advertisement is refused there whatever this file believes.
 */

export interface AdminActionResult {
  ok: boolean;
  message?: string;
  /** How many rows a bulk action actually changed. */
  count?: number;
  /** Filled when some of a bulk action failed, so the office can see which. */
  failures?: Array<{ reference: string; message: string }>;
}

const UNAVAILABLE: AdminActionResult = {
  ok: false,
  message: 'The site is running without a database connection.',
};

function refusal(error: unknown): AdminActionResult {
  if (error instanceof NotStaffError) return { ok: false, message: error.message };
  return {
    ok: false,
    message: 'That could not be saved just now. Please try again in a moment.',
  };
}

/**
 * Postgres raises with a message written for the person reading it — "An
 * advertisement cannot go from rejected to approved", "A reason is required to
 * reject an advertisement". Those are better than anything this layer could
 * invent, so they are passed through. Anything else is not: an internal error
 * text is not an explanation.
 */
function messageFor(error: { message?: string; code?: string } | null): string {
  const raw = error?.message ?? '';
  const known =
    /cannot go from|reason is required|Only Shree Classified|No such|Unknown moderation/i.test(raw);
  return known
    ? raw
    : 'That could not be saved just now. Please try again in a moment.';
}

/* ------------------------------------------------------- moderation -- */

export async function moderateAdvertisementAction(input: {
  advertisementId: string;
  action: string;
  note: string;
}): Promise<AdminActionResult> {
  if (!isSupabaseConfigured) return UNAVAILABLE;

  try {
    await requireStaff();
  } catch (error) {
    return refusal(error);
  }

  const parsed = moderationInputSchema.safeParse(input);
  if (!parsed.success) {
    return { ok: false, message: 'That is not a decision this office can record.' };
  }

  const supabase = await createSupabaseServerClient();
  const { error } = await supabase.rpc('moderate_advertisement', {
    p_ad_id: parsed.data.advertisementId,
    p_action: parsed.data.action,
    p_note: parsed.data.note || null,
  });

  if (error) return { ok: false, message: messageFor(error) };

  revalidateAdminAndPublic(parsed.data.advertisementId);
  return { ok: true, count: 1 };
}

/**
 * The same decision, applied to a selection.
 *
 * Sequential, not `Promise.all`. Twenty-five simultaneous round trips against
 * one Postgres connection pool is a good way to make the slowest one time out,
 * and more to the point each call has to be able to fail on its own: the point
 * of the failures list is that the office can see which three of the
 * twenty-five were refused and why, rather than being told the batch did not
 * work.
 */
export async function bulkModerateAction(input: {
  advertisementIds: string[];
  action: string;
  note: string;
}): Promise<AdminActionResult> {
  if (!isSupabaseConfigured) return UNAVAILABLE;

  try {
    await requireStaff();
  } catch (error) {
    return refusal(error);
  }

  const parsed = bulkModerationInputSchema.safeParse(input);
  if (!parsed.success) {
    return { ok: false, message: 'Please choose up to 25 advertisements and an action.' };
  }
  if (parsed.data.action === 'reject' && !parsed.data.note) {
    return { ok: false, message: 'A reason is needed to reject advertisements.' };
  }

  const supabase = await createSupabaseServerClient();
  const failures: Array<{ reference: string; message: string }> = [];
  let count = 0;

  for (const id of parsed.data.advertisementIds) {
    const { error } = await supabase.rpc('moderate_advertisement', {
      p_ad_id: id,
      p_action: parsed.data.action,
      p_note: parsed.data.note || null,
    });

    if (error) {
      const { data } = await supabase
        .from('moderation_ads')
        .select('reference')
        .eq('id', id)
        .maybeSingle();
      failures.push({ reference: data?.reference ?? id.slice(0, 8), message: messageFor(error) });
    } else {
      count += 1;
    }
  }

  revalidateAdminAndPublic();

  return {
    ok: failures.length === 0,
    count,
    failures: failures.length ? failures : undefined,
    message: failures.length
      ? `${count} done, ${failures.length} could not be changed.`
      : undefined,
  };
}

/* ---------------------------------------------------------- reports -- */

const reportInputSchema = z.object({
  reportId: z.uuid(),
  status: z.enum(['reviewing', 'actioned', 'dismissed']),
  note: z
    .string()
    .transform((value) => value.replace(/\s+/g, ' ').trim())
    .pipe(z.string().max(500)),
});

export async function resolveReportAction(input: {
  reportId: string;
  status: string;
  note: string;
}): Promise<AdminActionResult> {
  if (!isSupabaseConfigured) return UNAVAILABLE;

  try {
    await requireStaff();
  } catch (error) {
    return refusal(error);
  }

  const parsed = reportInputSchema.safeParse(input);
  if (!parsed.success) {
    return { ok: false, message: 'That is not something that can be done to a report.' };
  }

  const supabase = await createSupabaseServerClient();
  const { error } = await supabase.rpc('resolve_ad_report', {
    p_report_id: parsed.data.reportId,
    p_status: parsed.data.status,
    p_note: parsed.data.note || null,
  });

  if (error) return { ok: false, message: messageFor(error) };

  revalidatePath('/admin/reports');
  revalidatePath('/admin');
  return { ok: true, count: 1 };
}

/* ------------------------------------------------------------ users -- */

const blockInputSchema = z.object({ userId: z.uuid(), blocked: z.boolean() });

/**
 * Blocking an account.
 *
 * The one thing this interface can do to a person, and it is an
 * administrator's to do. There is deliberately no control anywhere in the
 * admin pages that grants a role: an interface that can make somebody an
 * administrator is an interface that can be tricked into making somebody an
 * administrator, and the office needs to do it roughly once. It is done in the
 * Supabase SQL editor, which the schema treats as a trusted connection — the
 * same route by which the first administrator exists at all.
 */
export async function setUserBlockedAction(input: {
  userId: string;
  blocked: boolean;
}): Promise<AdminActionResult> {
  if (!isSupabaseConfigured) return UNAVAILABLE;

  let administrator;
  try {
    administrator = await requireAdministrator();
  } catch (error) {
    return refusal(error);
  }

  const parsed = blockInputSchema.safeParse(input);
  if (!parsed.success) return { ok: false, message: 'That account could not be found.' };

  if (parsed.data.userId === administrator.id) {
    return { ok: false, message: 'You cannot block your own account.' };
  }

  const supabase = await createSupabaseServerClient();
  const { error } = await supabase
    .from('profiles')
    .update({ is_blocked: parsed.data.blocked })
    .eq('id', parsed.data.userId);

  if (error) return { ok: false, message: messageFor(error) };

  revalidatePath('/admin/users');
  return { ok: true, count: 1 };
}

/* ------------------------------------------------------- categories -- */

const categoryInputSchema = z.object({
  id: z.uuid().optional(),
  parentId: z.union([z.uuid(), z.literal('')]).optional(),
  name: z
    .string()
    .transform((value) => value.replace(/\s+/g, ' ').trim())
    .pipe(z.string().min(2, 'Please give the category a name.').max(60)),
  slug: z
    .string()
    .transform((value) => value.trim().toLowerCase())
    .pipe(
      z
        .string()
        .regex(
          /^[a-z0-9]+(-[a-z0-9]+)*$/,
          'A slug is lowercase letters, numbers and single hyphens.',
        ),
    ),
  description: z
    .string()
    .transform((value) => value.trim())
    .pipe(z.string().max(300)),
  sortOrder: z.number().int().min(0).max(9999),
  isActive: z.boolean(),
});

export async function saveCategoryAction(input: {
  id?: string;
  parentId?: string;
  name: string;
  slug: string;
  description: string;
  sortOrder: number;
  isActive: boolean;
}): Promise<AdminActionResult> {
  if (!isSupabaseConfigured) return UNAVAILABLE;

  try {
    await requireAdministrator();
  } catch (error) {
    return refusal(error);
  }

  const parsed = categoryInputSchema.safeParse(input);
  if (!parsed.success) {
    return {
      ok: false,
      message: parsed.error.issues[0]?.message ?? 'That category could not be saved.',
    };
  }

  const supabase = await createSupabaseServerClient();
  const row = {
    parent_id: parsed.data.parentId || null,
    slug: parsed.data.slug,
    name: parsed.data.name,
    description: parsed.data.description || null,
    sort_order: parsed.data.sortOrder,
    is_active: parsed.data.isActive,
  };

  const { error } = parsed.data.id
    ? await supabase.from('categories').update(row).eq('id', parsed.data.id)
    : await supabase.from('categories').insert(row);

  if (error) {
    // The slug is unique in the schema, which is the only failure worth
    // naming: everything else here is the office's own typing.
    if (error.code === '23505') {
      return { ok: false, message: 'Another category already uses that slug.' };
    }
    return { ok: false, message: messageFor(error) };
  }

  revalidatePath('/admin/categories');
  revalidatePath('/categories');
  revalidatePath('/classifieds');
  return { ok: true, count: 1 };
}

/*
 * There is no delete.
 *
 * A category with advertisements in it cannot be removed without deciding what
 * happens to them, and the schema says so — `categories` is referenced with ON
 * DELETE RESTRICT. Deactivating hides it from the public site and from the
 * submission form while leaving every advertisement where it is, which is what
 * "remove this category" almost always means in practice.
 */

/* ----------------------------------------------------- revalidation -- */

function revalidateAdminAndPublic(advertisementId?: string) {
  revalidatePath('/admin');
  revalidatePath('/admin/advertisements', 'layout');
  if (advertisementId) revalidatePath(`/admin/advertisements/${advertisementId}`);

  // Approving makes something public, and unpublishing takes it away again.
  // Both have to reach the reading side or the office will be looking at a
  // decision the site has not caught up with.
  revalidatePath('/classifieds', 'layout');
  revalidatePath('/');
  revalidatePath('/my-ads');
}
