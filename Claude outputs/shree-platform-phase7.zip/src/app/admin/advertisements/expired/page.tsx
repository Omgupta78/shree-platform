import type { Metadata } from 'next';

import { QueueView } from '@/components/admin/queue-view';
import type { RawSearchParams } from '@/lib/admin/query';

export const metadata: Metadata = { title: 'Expired' };

export default async function Page({
  searchParams,
}: {
  searchParams: Promise<RawSearchParams>;
}) {
  return (
    <QueueView
      title="Finished"
      description="Advertisements whose run has ended. Renewal is a later phase; restoring one sends it back through review."
      status={'expired'}
      basePath={'/admin/advertisements/expired'}
      searchParams={await searchParams}
      emptyTitle="Nothing has finished yet"
      emptyDescription="An advertisement appears here once its publication window has passed."
    />
  );
}
